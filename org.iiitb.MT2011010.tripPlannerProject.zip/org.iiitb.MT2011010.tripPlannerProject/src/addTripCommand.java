import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.jface.window.Window;
import org.eclipse.jface.wizard.WizardDialog;
import org.eclipse.ui.handlers.HandlerUtil;
import org.iiitb.mt2011010.tripplannerproject.TripAddWizard;


public class addTripCommand extends AbstractHandler {

	WizardDialog wizardDialog;
	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		// TODO Auto-generated method stub
		wizardDialog = new WizardDialog(HandlerUtil.getActiveShell(event),new TripAddWizard());
	    if (wizardDialog.open() == Window.OK) {
	      System.out.println("Added the Trip to Database");
	    } else {
	      System.out.println("Cancelled the Trip");
	       }
	    return wizardDialog;
	}

}
