package org.iiitb.mt2011010.tripplannerproject;

import java.util.Vector;

import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.ListViewer;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.KeyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.DateTime;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

public class TripDateAndAgentPage extends WizardPage {
  
  DateTime calendar;
  private Composite container;
  boolean flag;
  String travelAgentName;
  public String getTravelAgentName() {
	return travelAgentName;
}



public String getDate() {
	return date;
}


String date;
  Vector<String> agentsName = new Vector<String>();
  ListViewer listviewer;

  public TripDateAndAgentPage() {
    super("Final Data Submission Page");
    setTitle("Agent Selection and Date Confirmation");
    setDescription("Select the Agent You want to book the trip form and the date of the trip");
  }

  @Override
  public void createControl(Composite parent) {
    container = new Composite(parent, SWT.NULL);
    GridLayout layout = new GridLayout();
    container.setLayout(layout);
    layout.numColumns = 2;
    Label agent = new Label(container, SWT.NULL);
    agent.setText("Select a Travel Agent of Your Choice");

   
    
    
    agentsName.add("Make my Trip");
    agentsName.add("Yatra dot com");
    agentsName.add("Easy Trip");
    
    
    listviewer = new ListViewer(container,SWT.SINGLE);
    
    listviewer.setContentProvider(new ArrayContentProvider());  
    
  listviewer.setInput(agentsName);

 /* GridData griddata = new GridData(GridData.FILL_HORIZONTAL);
  griddata.minimumWidth = 50;
  
  listviewer.getControl().setLayoutData(griddata);
  */
  

  listviewer.addSelectionChangedListener(new ISelectionChangedListener() {
	         public void selectionChanged(SelectionChangedEvent event) {

	        	     flag=true;
	               
	        	 
	        	 IStructuredSelection selection =(IStructuredSelection) event.getSelection();
	            System.out.println("Selected: "
	               + selection.getFirstElement());
	            travelAgentName=selection.getFirstElement()+"";
	         }
	      });
	      
  Label dateSelection = new Label(container, SWT.NULL);
  dateSelection.setText("Select a Date of your Trip");
    calendar = new DateTime(container, SWT.CALENDAR);
    
    calendar.addSelectionListener (new SelectionAdapter () {
        public void widgetSelected (SelectionEvent e) {
         // text1.setData(" " + calendar.getYear() + "-" + (calendar.getMonth() + 1) + "-" + calendar.getDay());
          System.out.println(calendar.getYear());
          //text1.setText(calendar.getYear()+"");
          if (calendar.getEnabled()&&flag) {
              setPageComplete(true);

            }
          date=calendar.getDay()+"-"+(calendar.getMonth()+1)+"-"+calendar.getYear();
          //calendar.dispose();                   
        }
    }); 
    GridData gd = new GridData(GridData.FILL_HORIZONTAL);
   // calendar.setLayoutData(gd);
    listviewer.getControl().setLayoutData(gd);
    //listviewer.setLayoutData(gd);
    // Required to avoid an error in the system
    setControl(container);
    setPageComplete(false);

  }

  
} 