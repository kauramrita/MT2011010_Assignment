package org.iiitb.mt2011010.tripplannerproject;

import org.eclipse.ui.IPageLayout;
import org.eclipse.ui.IPerspectiveFactory;

public class supportPerspective implements IPerspectiveFactory {

	@Override
	public void createInitialLayout(IPageLayout layout) {
		// TODO Auto-generated method stub
		layout.setEditorAreaVisible(false);
		layout.addView("org.iiitb.MT2011010.tripPlannerProject.supportView", 0, 0.5f, "");

	}

}
