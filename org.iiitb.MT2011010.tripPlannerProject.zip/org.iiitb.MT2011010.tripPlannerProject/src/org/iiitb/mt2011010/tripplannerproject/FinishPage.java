package org.iiitb.mt2011010.tripplannerproject;

import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.KeyListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

public class FinishPage extends WizardPage {
  
  private Composite container;
  TripDateAndAgentPage tripConfirm=new TripDateAndAgentPage();
  TripNamePage tripName=new TripNamePage();
  TripPathPage tripPath=new TripPathPage();

  public FinishPage() {
    super("The Trip addition Confirmation");
    setTitle("Confirmation of Trip");
    setDescription("Your addition of Trip is confirmed");
    setControl(container);
  }

  @Override
  public void createControl(Composite parent) {
	  tripConfirm=new TripDateAndAgentPage();
	  tripName=new TripNamePage();
	   tripPath=new TripPathPage();

    container = new Composite(parent, SWT.NULL);
    GridLayout layout = new GridLayout();
    container.setLayout(layout);
    layout.numColumns = 2;
    Label confirm = new Label(container, SWT.NULL);
    confirm.setText("Your Trip is booked , please click Finish to confirm the booking");
    //+"\n\tfrom"+tripPath.getSourcePlace()+"\t to"+tripPath.getDescription()+"\n\t will be booked by"+tripConfirm.getTravelAgentName()+"\t of date"+tripConfirm.getDate()+"\n \n \t For Confirming the booking click Finish");

   
    GridData gd = new GridData(GridData.FILL_HORIZONTAL);
    
   confirm.setLayoutData(gd);
    // Required to avoid an error in the system
    setControl(container);
    setPageComplete(true);
  }

 
} 
