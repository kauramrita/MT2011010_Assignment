package org.iiitb.mt2011010.tripplannerproject;

import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.part.ViewPart;

public class supportView extends ViewPart {

	public supportView() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void createPartControl(Composite parent) {
		// TODO Auto-generated method stub

	}

	@Override
	public void setFocus() {
		// TODO Auto-generated method stub

	}

}
