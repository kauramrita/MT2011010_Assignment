package org.iiitb.mt2011010.tripplannerproject;



import java.sql.*;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.window.Window;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.ui.INewWizard;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.handlers.HandlerUtil;

import utils.MySqlConnection;


public class TripAddWizard extends Wizard implements INewWizard {
	
	MessageDialog messagedialog;
	Window parent;
  protected TripNamePage tripNamePage;
  protected TripPathPage tripPathPage;
  protected TripDateAndAgentPage tripDateAndAgentPage;
  protected FinishPage finishPage;

  public TripAddWizard() {
    super();
    setNeedsProgressMonitor(true);
  }

  @Override
  public void addPages() {
	  tripNamePage = new TripNamePage();
	  tripPathPage = new TripPathPage();
	  tripDateAndAgentPage = new TripDateAndAgentPage();
	  finishPage=new FinishPage();
    addPage(tripNamePage);
    addPage(tripPathPage);
    addPage(tripDateAndAgentPage);
    addPage(finishPage);
  }

  @Override
  public boolean performFinish() {
    // Print the result to the console
	  System.out.println("Values here");
    System.out.println(tripNamePage.getTripName());
    System.out.println(tripPathPage.getSourcePlace());
    System.out.println(tripPathPage.getDestinationPlace());
    System.out.println(tripPathPage.getStopageOne());
    	Connection con=MySqlConnection.getConnection();
    	Statement st=null;
    	int rs=0;
    	
    	String query="Insert into newTrip(tripName,source,destination,interOne,interTwo,interThree,tripPlannerAgent,tripDate) values('"+tripNamePage.getTripName()+"','"+tripPathPage.getSourcePlace()+"','"+tripPathPage.getDestinationPlace()+"','"+tripPathPage.getStopageOne()+"','"+tripPathPage.getStopageTwo()+"','"+tripPathPage.getStopageThree()+"','"+tripDateAndAgentPage.getTravelAgentName()+"','"+tripDateAndAgentPage.getDate()+"')";
    try {
    	st=con.createStatement();
		rs=st.executeUpdate(query);
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
 
    	return true;
  }

@Override
public void init(IWorkbench workbench, IStructuredSelection selection) {
	// TODO Auto-generated method stub
	
}
} 
