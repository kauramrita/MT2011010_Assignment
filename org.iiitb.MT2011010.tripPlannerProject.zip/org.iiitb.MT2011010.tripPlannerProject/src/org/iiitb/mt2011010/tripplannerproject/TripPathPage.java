package org.iiitb.mt2011010.tripplannerproject;

import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.KeyListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

public class TripPathPage extends WizardPage {
  private Text sourcePlace;
  public String getSourcePlace() {
	return sourcePlace.getText();
}

public void setSourcePlace(Text sourcePlace) {
	this.sourcePlace = sourcePlace;
}

public String getDestinationPlace() {
	return destinationPlace.getText();
}

public void setDestinationPlace(Text destinationPlace) {
	this.destinationPlace = destinationPlace;
}

public String getStopageOne() {
	return stopageOne.getText();
}

public void setStopageOne(Text stopageOne) {
	this.stopageOne = stopageOne;
}

public String getStopageTwo() {
	return stopageTwo.getText();
}

public void setStopageTwo(Text stopageTwo) {
	this.stopageTwo = stopageTwo;
}

public String getStopageThree() {
	return stopageThree.getText();
}

public void setStopageThree(Text stopageThree) {
	this.stopageThree = stopageThree;
}

private Text destinationPlace;
  private Text stopageOne;
  private Text stopageTwo;
  private Text stopageThree;
  private Composite container;

  public TripPathPage() {
    super("Details of Trip Page");
    setTitle("Details of Trip");
    setDescription("Trip Details need to be mentioned in this Page");
    setControl(sourcePlace);
  }

  @Override
  public void createControl(Composite parent) {
    container = new Composite(parent, SWT.NULL);
    GridLayout layout = new GridLayout();
    container.setLayout(layout);
    layout.numColumns = 2;
    Label source = new Label(container, SWT.NULL);
    source.setText("To :");

    sourcePlace = new Text(container, SWT.BORDER | SWT.SINGLE);
    sourcePlace.setText("");
    Label destination = new Label(container, SWT.NULL);
    destination.setText("From :");

    destinationPlace = new Text(container, SWT.BORDER | SWT.SINGLE);
    destinationPlace.setText("");
    Label interOne = new Label(container, SWT.NULL);
    interOne.setText("Via :");

    stopageOne = new Text(container, SWT.BORDER | SWT.SINGLE);
    stopageOne.setText("");
    stopageOne.addKeyListener(new KeyListener() {

      @Override
      public void keyPressed(KeyEvent e) {
        // TODO Auto-generated method stub

      }

      @Override
      public void keyReleased(KeyEvent e) {
        if (!sourcePlace.getText().isEmpty()) {
          setPageComplete(true);
        }
      }

    });
    Label interTwo = new Label(container, SWT.NULL);
    interTwo.setText("");
    stopageTwo = new Text(container, SWT.BORDER | SWT.SINGLE);
    stopageTwo.setText("");
    Label interThree = new Label(container, SWT.NULL);
    interThree.setText("");
    stopageThree = new Text(container, SWT.BORDER | SWT.SINGLE);
    stopageThree.setText("");
    GridData gd = new GridData(GridData.FILL_HORIZONTAL);
    sourcePlace.setLayoutData(gd);
    destinationPlace.setLayoutData(gd);
    stopageOne.setLayoutData(gd);
    stopageTwo.setLayoutData(gd);
    stopageThree.setLayoutData(gd);
   
    // Required to avoid an error in the system
    setControl(container);
    setPageComplete(false);
  }

  
} 
